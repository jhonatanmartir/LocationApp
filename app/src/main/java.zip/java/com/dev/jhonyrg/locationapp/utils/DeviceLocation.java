package com.dev.jhonyrg.locationapp.utils;

import android.content.Context;

import com.dev.jhonyrg.locationapp.ApplicationContext;

public class DeviceLocation implements LocationLatest.OnLocation, LocationFetch.OnLocationFetch{
    private LocationLatest locationLatest;
    private LocationFetch locationFetch;
    private OnDeviceLocation onDeviceLocation;

    public DeviceLocation(Context context) {
        this.locationLatest = new LocationLatest(context);
        this.locationFetch = new LocationFetch(context);
        this.onDeviceLocation = (OnDeviceLocation) context;
    }

    public void startLocalizationUpdates() {
        locationFetch.startLocationUpdates();
    }

    public void stopLocalizationUpdates() {
        locationFetch.stopLocationUpdates();
    }

    @Override
    public void onLocation(LocationData data) {
        onDeviceLocation.onLocalized(data);
    }

    @Override
    public void onSuccessLocation(LocationData data) {
        onDeviceLocation.onLocalized(data);
    }

    @Override
    public void onFailureSetting(Exception e) {
        onDeviceLocation.onFailed(e);
    }

    @Override
    public void onCompletedLocation(Boolean requestingUpdates) {
        onDeviceLocation.onCompleted();
    }

    public interface OnDeviceLocation{
        void onLocalized(LocationData data);
        void onFailed(Exception e);
        void onCompleted();
    }
}
