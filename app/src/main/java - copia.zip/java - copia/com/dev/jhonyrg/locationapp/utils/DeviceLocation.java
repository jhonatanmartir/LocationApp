package com.dev.jhonyrg.locationapp.utils;

import android.app.Activity;
import android.content.Context;

import com.dev.jhonyrg.locationapp.ApplicationContext;

public class DeviceLocation extends Activity implements LocationLatest.OnLocation, LocationFetch.OnLocationFetch{
    private LocationLatest locationLatest;
    private LocationFetch locationFetch;
    private OnDeviceLocation onDeviceLocation;
    private LocationLatest.OnLocation onLocationListener;
    private LocationFetch.OnLocationFetch onLocationFetchListener;

    public DeviceLocation(Context context, LocationLatest.OnLocation locationListener, LocationFetch.OnLocationFetch fetchListener, OnDeviceLocation listener) {
        this.onLocationListener = (LocationLatest.OnLocation) context;
        this.onLocationFetchListener = (LocationFetch.OnLocationFetch) context;
        this.locationLatest = new LocationLatest(context, onLocationListener);
        this.locationFetch = new LocationFetch(context, onLocationFetchListener);
//        this.onDeviceLocation = (OnDeviceLocation) context;
        this.onDeviceLocation = listener;
    }

    public void startLocalizationUpdates() {
        locationFetch.startLocationUpdates();
    }

    public void stopLocalizationUpdates() {
        locationFetch.stopLocationUpdates();
    }

    @Override
    public void onLocation(LocationData data) {
        onDeviceLocation.onLocalized(data);
    }

    @Override
    public void onSuccessLocation(LocationData data) {
        onDeviceLocation.onLocalized(data);
    }

    @Override
    public void onFailureSetting(Exception e) {
        onDeviceLocation.onFailed(e);
    }

    @Override
    public void onCompletedLocation(Boolean requestingUpdates) {
        onDeviceLocation.onCompleted();
    }

    public interface OnDeviceLocation{
        void onLocalized(LocationData data);
        void onFailed(Exception e);
        void onCompleted();
    }
}
