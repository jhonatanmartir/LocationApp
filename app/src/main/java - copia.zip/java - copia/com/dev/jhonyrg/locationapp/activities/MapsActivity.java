package com.dev.jhonyrg.locationapp.activities;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import com.dev.jhonyrg.locationapp.R;
import com.dev.jhonyrg.locationapp.utils.DeviceLocation;
import com.dev.jhonyrg.locationapp.utils.LocationData;
import com.dev.jhonyrg.locationapp.utils.LocationFetch;
import com.dev.jhonyrg.locationapp.utils.LocationLatest;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback, DeviceLocation.OnDeviceLocation {

    private GoogleMap mMap;
    private DeviceLocation deviceLocation;
    private DeviceLocation.OnDeviceLocation listener;
    private LocationLatest.OnLocation onLocationListener;
    private LocationFetch.OnLocationFetch onLocationFetchListener;
    private LocationData locationData;

    private LocationLatest myLocation;
    private LocationFetch myLocationFetch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        this.onLocationListener = (LocationLatest.OnLocation) this;
        this.onLocationFetchListener = (LocationFetch.OnLocationFetch) this;
        this.listener = this;
        this.deviceLocation = new DeviceLocation(getParent().getApplicationContext(), onLocationListener, onLocationFetchListener, listener);
        this.locationData = new LocationData();

//        this.myLocation = new LocationLatest(this);
//        this.myLocationFetch = new LocationFetch(this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.map_option_types, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Change the map type based on the user's selection.
        switch (item.getItemId()) {
            case R.id.normal_map:
                mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
                return true;
            case R.id.hybrid_map:
                mMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
                return true;
            case R.id.satellite_map:
                mMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
                return true;
            case R.id.terrain_map:
                mMap.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        deviceLocation.startLocalizationUpdates();
    }

    @Override
    protected void onPause() {
        super.onPause();
        deviceLocation.stopLocalizationUpdates();
    }

    private void addMarker(LocationData data){
        if(data != null){
            this.locationData = data;
            LatLng location = new LatLng(data.getLatitude(), data.getLongitude());
            mMap.addMarker(new MarkerOptions().position(location).title("Custom Locale"));
            mMap.moveCamera(CameraUpdateFactory.newLatLng(location));
        }
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        googleMap.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
        //addMarker(locationData);

        // Add a marker in Sydney and move the camera
        LatLng sydney = new LatLng(-34, 151);
        mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
    }

    @Override
    public void onLocalized(LocationData data) {
        addMarker(data);
    }

    @Override
    public void onFailed(Exception e) {

    }

    @Override
    public void onCompleted() {

    }
}
